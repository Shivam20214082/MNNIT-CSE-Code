else if (t1.getText() != "20214082") {
            //     String m = "message";
            //     String msg = "You Entered Incorrect Registration number";
            //     JOptionPane.showMessageDialog(b1, msg, m, 0);
            //     clear();
            // }
            // else if (t2.getText() != "11/12/2003") {
            //     String m = "message";
            //     String msg = "You Entered Incorrect DOB";
            //     JOptionPane.showMessageDialog(b1, msg, m, 0);
            //     clear();
            // }
            // else if (t3.getText() != "Jaunpur") {
            //     String m = "message";
            //     String msg = "You Entered Incorrect Address";
            //     JOptionPane.showMessageDialog(b1, msg, m, 0);
            //     clear();
            // }
            // else if (t4.getText() != "shivam66jnp@gmail.com") {
            //     String m = "message";
            //     String msg = "You Entered Incorrect Email id";
            //     JOptionPane.showMessageDialog(b1, msg, m, 0);
            //     clear();
            // }
            // else if (t5.getText() != "8736093895") {
            //     String m = "message";
            //     String msg = "You Entered Incorrect Mobile number";
            //     JOptionPane.showMessageDialog(b1, msg, m, 0);
            //     clear();