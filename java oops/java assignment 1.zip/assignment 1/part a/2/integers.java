//Shivam Kumar Gupta
//20214082
//Group CSE-D
import java.io.* ;
import java.util.Scanner;
class pint{
public static void main(String[] args){
int num= 10;
int num1;
System.out.println("Enter a number");
Scanner s=new Scanner(System.in);
num1=s.nextInt();
//System.out.println(num);
System.out.println("Your enter no. is:");
System.out.println(num1);
}
}
//output//
/*
C:\Users\shiva\Desktop\java>java pint
Enter a number
35
Your enter no. is:
35
*/

