//Shivam Kumar Gupta
//20214082
//Group CSE-D
import java.util.Scanner;
class eodd{
public static void main(String[] args){
System.out.println("Enter a number");
Scanner s=new Scanner(System.in);
int a=s.nextInt();
if(a%2==0){
System.out.println("Number is Even");
}
else
System.out.println("Number is odd");
}
}
//output//
/*
Enter a number
69
Number is odd
*/
