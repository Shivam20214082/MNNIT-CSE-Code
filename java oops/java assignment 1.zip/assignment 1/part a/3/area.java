//Shivam Kumar Gupta
//20214082
//Group CSE-D
import java.io.*;
import java.util.Scanner;
class area{
public static void main(String[] args){
System.out.println("Enter radius of circle");
int a;
Scanner s = new Scanner(System.in);
a=s.nextInt();
System.out.println("Area of circlr is:");
System.out.println(3.14*a*a);
}
}
//output//
/*
Enter radius of circle
7
Area of circlr is:
153.86
*/
